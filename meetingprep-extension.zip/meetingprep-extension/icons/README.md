# Extension Icons

You need to add the following icon files:
- icon16.png (16x16 pixels)
- icon48.png (48x48 pixels) 
- icon128.png (128x128 pixels)

For now, you can use any PNG images with these dimensions, or create simple colored squares.

Recommended: Use a blue/purple gradient square with "MP" text or a calendar/AI icon.

You can generate these at: https://favicon.io/ or use any image editor.


